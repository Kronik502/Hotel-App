<<<<<<< HEAD
=======
// src/Components/Footer.js
>>>>>>> 892298a (Initial commit)
import React, { useState } from 'react';
import '../styles/Footer.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

function Footer() {
  const [formData, setFormData] = useState({
    email: '',
    query: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.email || !formData.query) {
      alert('Please fill in all fields');
    } else {
<<<<<<< HEAD
      // Handle form submission (e.g., send form data to backend)
=======
>>>>>>> 892298a (Initial commit)
      alert('Thank you for your enquiry!');
    }
  };

  return (
    <footer className="footer">
      <div className="footer-content">
<<<<<<< HEAD

=======
>>>>>>> 892298a (Initial commit)
        <div className="social-icons">
          <a href="https://facebook.com" aria-label="Facebook">
            <i className="fab fa-facebook-f"></i>
          </a>
          <a href="https://twitter.com" aria-label="Twitter">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="https://instagram.com" aria-label="Instagram">
            <i className="fab fa-instagram"></i>
          </a>
          <a href="https://whatsapp.com" aria-label="WhatsApp">
            <i className="fab fa-whatsapp"></i>
          </a>
        </div>

        <div className="personal-info">
<<<<<<< HEAD
          <img src={require('../images/ceo.jpg')} alt="CEO" className="ceo-image" />
          <p className="ceo-title">CEO</p>
          <p className="ceo-name">Kgabo Kwenaite</p>

=======
          <img src={require('../assets/ceo.jpg')} alt="CEO" className="ceo-image" />
          <p className="ceo-title">CEO</p>
          <p className="ceo-name">Kgabo Kwenaite</p>
>>>>>>> 892298a (Initial commit)
        </div>
      </div>

      <div className="footer-bottom">
        <p>© 2024 Deluxe Hotel. All Rights Reserved. Unparalleled luxury, unforgettable experiences.</p>
      </div>
    </footer>
  );
}

<<<<<<< HEAD
export default Footer;
=======
export default Footer
>>>>>>> 892298a (Initial commit)
