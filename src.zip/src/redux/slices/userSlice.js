<<<<<<< HEAD
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  users: [],
  isLoggedIn: false,
  currentUser: null,
=======
// src/redux/slices/userSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  user: null,
>>>>>>> 892298a (Initial commit)
  error: null,
};

const userSlice = createSlice({
<<<<<<< HEAD
  name: 'users',
  initialState,
  reducers: {
    addUser: (state, action) => {
      state.users.push(action.payload);
    },
    setLogin: (state, action) => {
      state.isLoggedIn = true;
      state.currentUser = action.payload;
    },
    logout: (state) => {
      state.isLoggedIn = false;
      state.currentUser = null;
    },
    loginSuccess: (state, action) => {
      state.isLoggedIn = true;
      state.currentUser = action.payload;
=======
  name: 'user',
  initialState,
  reducers: {
    loginSuccess: (state, action) => {
      state.user = action.payload;
      state.error = null;
    },
    registerSuccess: (state, action) => {
      state.user = action.payload;
      state.error = null;
>>>>>>> 892298a (Initial commit)
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
<<<<<<< HEAD
    registerSuccess: (state, action) => {
      state.users.push(action.payload); // Add the new user to the user list
      state.currentUser = action.payload; // Automatically log in the new user
      state.isLoggedIn = true;
    },
  },
});

export const {
  addUser,
  setLogin,
  logout,
  loginSuccess,
  setError,
  registerSuccess,
} = userSlice.actions;
=======
  },
});

export const { loginSuccess, registerSuccess, setError } = userSlice.actions;
>>>>>>> 892298a (Initial commit)

export default userSlice.reducer;
