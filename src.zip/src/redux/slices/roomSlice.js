// src/redux/slices/roomSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  rooms: [],
<<<<<<< HEAD
=======
  loading: false,
>>>>>>> 892298a (Initial commit)
};

const roomSlice = createSlice({
  name: 'rooms',
  initialState,
  reducers: {
<<<<<<< HEAD
    addRoom: (state, action) => {
      state.rooms.push(action.payload);
    },
    updateRoom: (state, action) => {
      const index = state.rooms.findIndex((room) => room.id === action.payload.id);
      if (index !== -1) state.rooms[index] = action.payload;
    },
    deleteRoom: (state, action) => {
      state.rooms = state.rooms.filter((room) => room.id !== action.payload);
=======
    fetchRoomsSuccess: (state, action) => {
      state.rooms = action.payload;
      state.loading = false;
>>>>>>> 892298a (Initial commit)
    },
  },
});

<<<<<<< HEAD
export const { addRoom, updateRoom, deleteRoom } = roomSlice.actions;
=======
export const { fetchRoomsSuccess } = roomSlice.actions;

>>>>>>> 892298a (Initial commit)
export default roomSlice.reducer;
