<<<<<<< HEAD
// src/redux/store.js
import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slices/userSlice';
import roomReducer from './slices/roomSlice';
import paymentReducer from './slices/PaymentSlice';


export const store = configureStore({
  reducer: {
    users: userReducer,
    rooms: roomReducer,
    payment: paymentReducer,
=======
// /redux/store.js
import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slices/userSlice';
import roomReducer from './slices/roomSlice';  // For handling room data

export const store = configureStore({
  reducer: {
    user: userReducer,
    rooms: roomReducer,
>>>>>>> 892298a (Initial commit)
  },
});

export default store;
