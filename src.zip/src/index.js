<<<<<<< HEAD
import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import store from './redux/store'; // Your Redux store
import App from './App';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Provider store={store}>
      <Router>
        <App />
      </Router>
    </Provider>
  </React.StrictMode>
=======
// src/index.js
import React from 'react';
import ReactDOM from 'react-dom';
import './styles/index.css';
import App from './App';
import { Provider } from 'react-redux';  // Import Provider
import { store } from './redux/store';    // Import the store

ReactDOM.render(
  <Provider store={store}>    {/* Wrap App in Provider */}
    <App />
  </Provider>,
  document.getElementById('root')
>>>>>>> 892298a (Initial commit)
);
